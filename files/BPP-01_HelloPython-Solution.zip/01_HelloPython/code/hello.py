print("Hello Aline and Basti!")

print("What's up?")

# We need escaping: \" cancels its meaning.
print("Are you \"Monty\"?")
# Alternatively you can use ':
print('Are you "Monty"?')

# But you will need escaping for the last:
print("Can't you just pretend you were \"Monty\"?")
# or
print('Can\'t you just pretend you were "Monty"?')

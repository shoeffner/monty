x = 64
sqrt_x = x ** (1 / 2)
print(sqrt_x)
y = 8
cbrt_y = y ** (1 / 3)
print(cbrt_y)

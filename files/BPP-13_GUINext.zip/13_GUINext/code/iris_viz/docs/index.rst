The iris visualizer -- get to know your iris data!
==================================================

This little tool allow to visualize the iris data by Fisher, which can be found
at the `UCI Machine Learning repository`_.

.. image:: image.png

You can run it with `python visualize_iris.py`.

.. _UCI Machine Learning repository: https://archive.ics.uci.edu/ml/datasets/Iris

.. toctree::
   :maxdepth: 2

   modules/modules


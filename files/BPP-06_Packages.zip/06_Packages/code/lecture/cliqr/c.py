def printer():
    print('Hello World! d')

print('Hello World! c')

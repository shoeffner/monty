import reader


data = reader.read_data('example.data')
print(data)
